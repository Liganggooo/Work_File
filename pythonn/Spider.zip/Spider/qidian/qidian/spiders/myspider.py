# -*- coding: utf-8 -*-
import scrapy
import lxml
import sys
sys.path.append(r'C:\Users\lg\Desktop\Python\qidian')
from qidian.items import QidianItem
# from scrapy.linkextractors import LinkExtractor
# from scrapy.spiders import CrawlSpider, Rule


class MyspiderSpider(scrapy.Spider):
    name = 'myspider'
    allowed_domains = ['qidian.com']
    url = 'https://www.qidian.com/rank/yuepiao?page='
    offset = 1
    start_urls = [url + str(offset)]

    # pagelink = LinkExtractor(allow = r'//book.qidian.com/info/\d+')

    # rules = (
        # Rule(pagelink, callback = 'parse_item')
    # )
    def parse(self,response):
        response = lxml.etree.HTML(response.text)
        links = response.xpath('//*[@class="book-img-text"]//li//div[2]/h4/a/@href')
        for link in links:

            yield scrapy.Request('https:' + link,callback = self.parse_item)


        if self.offset <= 25:
            self.offset += 1

            yield scrapy.Request(self.url + str(self.offset),callback = self.parse)


    def parse_item(self, response):
        response = lxml.etree.HTML(response.text)
        item = QidianItem()
        # i = {}
        #i['domain_id'] = response.xpath('//input[@id="sid"]/@value').extract()
        #i['name'] = response.xpath('//div[@id="name"]').extract()
        #i['description'] = response.xpath('//div[@id="description"]').extract()
        # return i
        item['novel_name'] = response.xpath('/html/body/div[2]/div[6]/div[1]//h1/em/text()')[0]
        item['author'] = response.xpath('/html/body/div[2]/div[6]/div[1]//h1/span/a/text()')[0]
        item['monthCount'] = response.xpath('//*[@id="monthCount"]/text()')[0]

        
        yield item










