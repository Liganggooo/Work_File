# -*- coding: utf-8 -*-
#创建一个爬虫文件scrapy genspider myspeider douban.com
import scrapy
import sys
sys.path.append(r'C:\Users\lg\Desktop\Python\dbSpider')
from dbSpider.items import DbspiderItem
from bs4 import BeautifulSoup
import lxml

class MyspiderSpider(scrapy.Spider):
	name = 'novel'
	allowed_domains = ['sogou.com']

	
	url = 'https://xs.sogou.com/1_0_0_0_heat/?pageNo='

	offset = 1
	start_urls = [url + str(offset)]

	def parse(self, response):
		item = DbspiderItem()
		html = response.text
		soup = BeautifulSoup(html,'lxml')
		infos = soup.select('.filter-ret.clear')[0]
		infos = infos.select('.fl.clear')
		# novelItem = []
		for info in infos:
			title = info.select('h3')[0].get_text()
			# print(title)
			author = info.select('.d1')[0].get_text()
			# print(author)
			intro = info.select('.d2')[0].get_text()
			# print(intro + '\n')
			item['title'] = title
			item['author'] = author
			item['intro'] = intro
			# novelItem.append(item)

		# return novelItem
			yield item

		if self.offset  < 50:
			self.offset += 1

		yield scrapy.Request(self.url + str(self.offset), callback = self.parse)
		print('正在采集下一页....')





