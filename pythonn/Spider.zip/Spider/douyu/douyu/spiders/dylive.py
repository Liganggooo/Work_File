# -*- coding: utf-8 -*-
import scrapy
import sys
sys.path.append(r'C:\Users\lg\Desktop\Python\spider\douyu')
from douyu.items import DouyuItem
from bs4 import BeautifulSoup
import lxml

class DyliveSpider(scrapy.Spider):
	name = 'dylive'
	allowed_domains = ['douyu.com']
	start_urls = ['https://www.douyu.com/directory/game/LOL']

	def parse(self, response):
		# pass
		item = DouyuItem()
		html = response.text
		soup = BeautifulSoup(html,'lxml')
		infos = soup.select('.play-list-link')
		for info in infos:
			item['title'] = info['title']
			item['name'] = info.select('.mes-tit')[0].select('span')[0].get_text()
			item['tag'] = info.select('.mes')[0]('span')[1].get_text()
			item['enrages'] =  info.select('.mes')[0]('span')[2].get_text()

			yield item








