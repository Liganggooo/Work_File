# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import pymongo
from scrapy.conf import settings

class DouyuPipeline(object):
	def __init__(self):
		host = settings['MONGO_URL']
		dbname = settings['MONGO_DB']
		sheetname = settings['MONGO_TABLE']
		client = pymongo.MongoClient(host)
		db = client[dbname]
		self.sheet = db[sheetname]

	def process_item(self, item, spider):
		result = dict(item)
		self.sheet.insert(result)
		return item